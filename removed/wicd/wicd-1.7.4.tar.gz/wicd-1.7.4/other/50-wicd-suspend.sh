#!/bin/sh
# Put wifi interface down
/usr/share/wicd/daemon/suspend.py
