#!/bin/sh
# Bring wifi network interface back up.

/usr/share/wicd/daemon/autoconnect.py
