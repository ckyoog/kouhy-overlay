/* 
 * frame support
 */

enum {
    F_BODY,
    F_FRAMESET,
};

struct frame_element {
    char attr;
    char *name;
};

struct frame_body {
    char attr;
    char *name;
    char *url;
    ParsedURL *baseURL;
    char *referer;
    FormList *request;
};

union frameset_element {
    struct frame_element *element;
    struct frame_body *body;
    struct frameset *set;
};

struct frameset {
    char attr;
    char *name;
    struct _Buffer *origin;
    char **width;
    char **height;
    int col;
    int row;
    int i;
    union frameset_element *frame;
};

/* Local Variables:    */
/* c-basic-offset: 4   */
/* tab-width: 8        */
/* End:                */
