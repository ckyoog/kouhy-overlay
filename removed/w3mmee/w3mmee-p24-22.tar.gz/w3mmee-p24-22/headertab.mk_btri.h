#include "config.h"
%%BEGIN special_headertab
#undef def_header
#define def_header(cname, hname) hname,&special_headerv[headerno_ ## cname]
#include "headerv.h"
