def_scheme("http", SCM_HTTP, "http", 80, FALSE)
def_scheme("gopher", SCM_GOPHER, "gopher", 70, FALSE)
def_scheme("ftp", SCM_FTP, "ftp", 21, FALSE)
def_scheme(":ftpdir", SCM_FTPDIR, "ftp", 21, TRUE)
def_scheme(":local-cgi", SCM_LOCAL_CGI, "file", 0, TRUE)
def_scheme("file", SCM_LOCAL, "file", 0, FALSE)
def_scheme("nntp", SCM_NNTP, "nntp", 119, FALSE)
def_scheme("news", SCM_NEWS, "news", 119, FALSE)
def_scheme("mailto", SCM_MAILTO, "mailto", 0, FALSE)
#ifdef USE_SSL
def_scheme("https", SCM_HTTPS, "https", 443, FALSE)
#endif				/* USE_SSL */
