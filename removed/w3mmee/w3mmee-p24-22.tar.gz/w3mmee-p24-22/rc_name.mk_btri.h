#include "config.h"

#define STRING_LITERAL(x) # x
#undef def_rcsect_begin
#define def_rcsect_begin(n) STRING_LITERAL(* ## n), &sections[secti_ ## n]

#undef def_rcsect_end
#define def_rcsect_end(n)

#if LANG == MANY

#undef def_mbsetup
#define def_mbsetup(key, mac, inputtype, eng) def_rcitem(key, P_MBSETUP, inputtype, NULL, eng, NULL)


#undef def_rcstr
#define def_rcstr(key, man, ini, eng) def_rcitem(key, P_STRING, PI_TEXT, &RCSTR_ ## mac, eng, NULL)

#endif

#undef def_rcitem
#define def_rcitem(name, type, inputtype, varptr, comment, select) # name, &paramv[rcitem_ ## name]

%%BEGIN rc_paramtab

#include "rc.h"
