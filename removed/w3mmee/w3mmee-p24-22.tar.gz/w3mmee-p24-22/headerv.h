def_header(CONTENT_TRANSFER_ENCODING,"content-transfer-encoding")
def_header(CONTENT_ENCODING,"content-encoding")
#ifdef USE_COOKIE
def_header(SET_COOKIE,"set-cookie")
def_header(SET_COOKIE2,"set-cookie2")
#endif
#if defined(USE_IMAGE) && defined(USE_XFACE)
def_header(X_FACE,"x-face")
#endif
def_header(W3M_CTL,"w3m-control")
