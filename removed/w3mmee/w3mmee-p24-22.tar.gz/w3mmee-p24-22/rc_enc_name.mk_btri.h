%%BEGIN stdenc_tab
"ujis","eucjp"
"euc-jp","eucjp"
"shift_jis","sjis"
"utf8","utf-8"
