#include "config.h"
%%BEGIN HTTPAutoHeader
"user-agent",(void *)&UserAgent
"accept",(void *)&AcceptMedia
"accept-encoding",(void *)&AcceptEncoding
"accept-language",(void *)&AcceptLang
"referer",(void *)&UserSpecifiedReferer
"host",NULL
"pragma",NULL
"cache-control",NULL
#ifdef USE_COOKIE
"cookie",(void *)&UserSpecifiedCookie
"cookie2",(void *)&UserSpecifiedCookie2
#endif /* USE_COOKIE */
"content-type",(void *)&UserSpecifiedContentType
"content-length",NULL
