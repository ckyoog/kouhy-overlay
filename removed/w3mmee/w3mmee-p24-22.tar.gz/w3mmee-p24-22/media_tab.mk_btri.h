%%BEGIN default_media_tab
#undef def_content_encoding
#define def_content_encoding(cname, enc, media, decnam, deccmd) media,&cev[content_encoding_ ## cname]
#include "content_encoding.h"
