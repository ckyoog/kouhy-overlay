#include "config.h"

#if LANG == MANY
#define VERSION_SUFFIX ""
#elif LANG == JA
#define VERSION_SUFFIX "-ja"
#else
#define VERSION_SUFFIX "-en"
#endif

#define CURRENT_VERSION "w3m/0.3.2+mee-p24-22"

#ifndef FM_H
char *w3m_version = CURRENT_VERSION VERSION_SUFFIX;
#endif				/* not FM_H */
