%%BEGIN default_ce_tab
#undef def_content_encoding
#define def_content_encoding(cname, enc, media, decnam, deccmd) enc,&cev[content_encoding_ ## cname]
#include "content_encoding.h"
