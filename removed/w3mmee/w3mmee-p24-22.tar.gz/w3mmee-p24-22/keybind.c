
/* Marker extension by okabe */
/* $Id: keybind.c,v 1.1.1.1.6.4.4.13 2002/09/16 11:34:40 suto Exp $ */
#include "fm.h"

static KeyTabItem w3mDefaultFuncKeyTab[] = {
#ifdef __EMX__
  K_SET_FUNC(K_GEN(0, K_CTL_ATMARK), FUNCNAME_pcmap),
#else
  K_SET_FUNC(K_GEN(0, K_CTL_ATMARK), FUNCNAME__mark),
#endif
  K_SET_FUNC(K_GEN(0, K_CTL_A), FUNCNAME_linbeg),
  K_SET_FUNC(K_GEN(0, K_CTL_B), FUNCNAME_movL),
  K_SET_FUNC(K_GEN(0, K_CTL_D), FUNCNAME_nextA),
  K_SET_FUNC(K_GEN(0, K_CTL_E), FUNCNAME_linend),
  K_SET_FUNC(K_GEN(0, K_CTL_F), FUNCNAME_movR),
  K_SET_FUNC(K_GEN(0, K_CTL_G), FUNCNAME_curlno),
  K_SET_FUNC(K_GEN(0, K_CTL_H), FUNCNAME_ldHist),
  K_SET_FUNC(K_GEN(0, K_CTL_I), FUNCNAME_next_frame),
  K_SET_FUNC(K_GEN(0, K_CTL_J), FUNCNAME_followA),
  K_SET_FUNC(K_GEN(0, K_CTL_K), FUNCNAME_cooLst),
  K_SET_FUNC(K_GEN(0, K_CTL_L), FUNCNAME_rdrwSc),
  K_SET_FUNC(K_GEN(0, K_CTL_M), FUNCNAME_followA),
  K_SET_FUNC(K_GEN(0, K_CTL_N), FUNCNAME_movD),
  K_SET_FUNC(K_GEN(0, K_CTL_P), FUNCNAME_movU),
  K_SET_FUNC(K_GEN(0, K_CTL_R), FUNCNAME_isrchbak),
  K_SET_FUNC(K_GEN(0, K_CTL_S), FUNCNAME_isrchfor),
  K_SET_FUNC(K_GEN(0, K_CTL_U), FUNCNAME_prevA),
  K_SET_FUNC(K_GEN(0, K_CTL_V), FUNCNAME_pgFore),
  K_SET_FUNC(K_GEN(0, K_CTL_W), FUNCNAME_wrapToggle),
  K_SET_FUNC(K_GEN(0, K_CTL_Z), FUNCNAME_susp),
  K_SET_FUNC(K_GEN(0, K_CTL_LBRACKET), FUNCNAME_escmap),
  K_SET_FUNC(K_GEN(0, K_SPACE), FUNCNAME_pgFore),
  K_SET_FUNC(K_GEN(0, K_SYM_EXCLM), FUNCNAME_execsh),
  K_SET_FUNC(K_GEN(0, K_SYM_DQ), FUNCNAME_reMark),
  K_SET_FUNC(K_GEN(0, K_SYM_SHARP), FUNCNAME_pipesh),
  K_SET_FUNC(K_GEN(0, K_SYM_DOLLAR), FUNCNAME_linend),
  K_SET_FUNC(K_GEN(0, K_SYM_COMMA), FUNCNAME_col1L),
  K_SET_FUNC(K_GEN(0, K_SYM_DOT), FUNCNAME_col1R),
  K_SET_FUNC(K_GEN(0, K_SYM_SLASH), FUNCNAME_srchfor),
  K_SET_FUNC(K_GEN(0, K_SYM_COLON), FUNCNAME_chkURL),
  K_SET_FUNC(K_GEN(0, K_SYM_SEMICOLON), FUNCNAME_chkWORD),
  K_SET_FUNC(K_GEN(0, K_SYM_LT), FUNCNAME_shiftl),
  K_SET_FUNC(K_GEN(0, K_SYM_EQ), FUNCNAME_pginfo),
  K_SET_FUNC(K_GEN(0, K_SYM_GT), FUNCNAME_shiftr),
  K_SET_FUNC(K_GEN(0, K_SYM_QUESTION), FUNCNAME_srchbak),
  K_SET_FUNC(K_GEN(0, K_SYM_ATMARK), FUNCNAME_readsh),
  K_SET_FUNC(K_GEN(0, K_ALPHA_B), FUNCNAME_backBf),
  K_SET_FUNC(K_GEN(0, K_ALPHA_E), FUNCNAME_editBf),
  K_SET_FUNC(K_GEN(0, K_ALPHA_F), FUNCNAME_rFrame),
  K_SET_FUNC(K_GEN(0, K_ALPHA_G), FUNCNAME_goLineL),
  K_SET_FUNC(K_GEN(0, K_ALPHA_H), FUNCNAME_ldhelp),
  K_SET_FUNC(K_GEN(0, K_ALPHA_I), FUNCNAME_followI),
  K_SET_FUNC(K_GEN(0, K_ALPHA_J), FUNCNAME_lup1),
  K_SET_FUNC(K_GEN(0, K_ALPHA_K), FUNCNAME_ldown1),
  K_SET_FUNC(K_GEN(0, K_ALPHA_M), FUNCNAME_extbrz),
  K_SET_FUNC(K_GEN(0, K_ALPHA_N), FUNCNAME_srchprv),
  K_SET_FUNC(K_GEN(0, K_ALPHA_Q), FUNCNAME_quitfm),
  K_SET_FUNC(K_GEN(0, K_ALPHA_R), FUNCNAME_reload_view),
  K_SET_FUNC(K_GEN(0, K_ALPHA_S), FUNCNAME_svBuf),
  K_SET_FUNC(K_GEN(0, K_ALPHA_U), FUNCNAME_goURL),
  K_SET_FUNC(K_GEN(0, K_ALPHA_V), FUNCNAME_ldfile),
  K_SET_FUNC(K_GEN(0, K_ALPHA_W), FUNCNAME_movLW),
  K_SET_FUNC(K_GEN(0, K_ALPHA_Z), FUNCNAME_ctrCsrH),
  K_SET_FUNC(K_GEN(0, K_SYM_LBRACKET), FUNCNAME_topA),
  K_SET_FUNC(K_GEN(0, K_SYM_RBRACKET), FUNCNAME_lastA),
  K_SET_FUNC(K_GEN(0, K_SYM_HAT), FUNCNAME_linbeg),
  K_SET_FUNC(K_GEN(0, K_ALPHA_a), FUNCNAME_svA),
  K_SET_FUNC(K_GEN(0, K_ALPHA_b), FUNCNAME_pgBack),
  K_SET_FUNC(K_GEN(0, K_ALPHA_c), FUNCNAME_curURL),
  K_SET_FUNC(K_GEN(0, K_ALPHA_g), FUNCNAME_goLineF),
  K_SET_FUNC(K_GEN(0, K_ALPHA_h), FUNCNAME_movL),
  K_SET_FUNC(K_GEN(0, K_ALPHA_i), FUNCNAME_peekIMG),
  K_SET_FUNC(K_GEN(0, K_ALPHA_j), FUNCNAME_movD),
  K_SET_FUNC(K_GEN(0, K_ALPHA_k), FUNCNAME_movU),
  K_SET_FUNC(K_GEN(0, K_ALPHA_l), FUNCNAME_movR),
  K_SET_FUNC(K_GEN(0, K_ALPHA_n), FUNCNAME_srchnxt),
  K_SET_FUNC(K_GEN(0, K_ALPHA_o), FUNCNAME_ldOpt),
  K_SET_FUNC(K_GEN(0, K_ALPHA_q), FUNCNAME_qquitfm),
  K_SET_FUNC(K_GEN(0, K_ALPHA_s), FUNCNAME_selMn),
  K_SET_FUNC(K_GEN(0, K_ALPHA_u), FUNCNAME_peekURL),
  K_SET_FUNC(K_GEN(0, K_ALPHA_v), FUNCNAME_vwSrc),
  K_SET_FUNC(K_GEN(0, K_ALPHA_w), FUNCNAME_movRW),
  K_SET_FUNC(K_GEN(0, K_ALPHA_z), FUNCNAME_ctrCsrV),
  K_SET_FUNC(K_GEN(0, K_ESC | K_CTL_I), FUNCNAME_prev_frame),
  K_SET_FUNC(K_GEN(0, K_ESC | K_CTL_J), FUNCNAME_svA),
  K_SET_FUNC(K_GEN(0, K_ESC | K_CTL_M), FUNCNAME_svA),
  K_SET_FUNC(K_GEN(0, K_ESC | K_SYM_COLON), FUNCNAME_chkNMID),
  K_SET_FUNC(K_GEN(0, K_ESC | K_SYM_LT), FUNCNAME_goLineF),
  K_SET_FUNC(K_GEN(0, K_ESC | K_SYM_GT), FUNCNAME_goLineL),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_I), FUNCNAME_svI),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_M), FUNCNAME_linkbrz),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_O), FUNCNAME_escbmap),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_W), FUNCNAME_dictwordat),
  K_SET_FUNC(K_GEN(0, K_ESC | K_SYM_LBRACKET), FUNCNAME_escbmap),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_a), FUNCNAME_adBmark),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_b), FUNCNAME_ldBmark),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_e), FUNCNAME_editScr),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_g), FUNCNAME_goLine),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_n), FUNCNAME_nextMk),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_p), FUNCNAME_prevMk),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_s), FUNCNAME_svSrc),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_u), FUNCNAME_gorURL),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_v), FUNCNAME_pgBack),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_w), FUNCNAME_dictword),
  K_SET_FUNC(K_GEN(0, K_ESC | K_ALPHA_x), FUNCNAME_callfunc),
  K_SET_FUNC(K_GEN(0, K_UP), FUNCNAME_movU),
  K_SET_FUNC(K_GEN(0, K_DOWN), FUNCNAME_movD),
  K_SET_FUNC(K_GEN(0, K_RIGHT), FUNCNAME_movR),
  K_SET_FUNC(K_GEN(0, K_LEFT), FUNCNAME_movL),
  K_SET_FUNC(K_GEN(0, K_END), FUNCNAME_goLineL),
  K_SET_FUNC(K_GEN(0, K_PGDN), FUNCNAME_pgFore),
  K_SET_FUNC(K_GEN(0, K_HOME), FUNCNAME_goLineF),
  K_SET_FUNC(K_GEN(0, K_PGUP), FUNCNAME_pgBack),
  K_SET_FUNC(K_GEN(0, K_XTERM_MOUSE), FUNCNAME_mouse),
  K_SET_FUNC(K_GEN(0, K_PAD_HOME), FUNCNAME_goLineF),
  K_SET_FUNC(K_GEN(0, K_PAD_INS), FUNCNAME_mainMn),
  K_SET_FUNC(K_GEN(0, K_PAD_END), FUNCNAME_goLineL),
  K_SET_FUNC(K_GEN(0, K_PAD_PGUP), FUNCNAME_pgBack),
  K_SET_FUNC(K_GEN(0, K_PAD_PGDN), FUNCNAME_pgFore),
  K_SET_FUNC(K_GEN(0, K_PAD_HELP), FUNCNAME_mainMn),
#ifdef USE_MOUSE
  K_SET_FUNC(K_GEN(0, K_MOUSE(CLICK) + MOUSE_BTN1_DOWN), FUNCNAME_gotoXY),
  K_SET_FUNC(K_GEN(0, K_MOUSE(CLICK) + MOUSE_BTN2_DOWN), FUNCNAME_backBf),
  K_SET_FUNC(K_GEN(0, K_MOUSE(CLICK) + MOUSE_BTN3_DOWN), FUNCNAME_mainMn),
  K_SET_FUNC(K_GEN(0, K_MOUSE(CLICK) + MOUSE_BTN4_DOWN), FUNCNAME_ldown1),
  K_SET_FUNC(K_GEN(0, K_MOUSE(CLICK) + MOUSE_BTN5_DOWN), FUNCNAME_lup1),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DCLICK) + MOUSE_BTN1_DOWN), FUNCNAME_followA),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DCLICK) + MOUSE_BTN2_DOWN), FUNCNAME_backBf),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DCLICK) + MOUSE_BTN3_DOWN), FUNCNAME_mainMn),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DRAG) + MOUSE_BTN1_DOWN), FUNCNAME_scrollXY),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DRAG) + MOUSE_BTN2_DOWN), FUNCNAME_backBf),
  K_SET_FUNC(K_GEN(0, K_MOUSE(DRAG) + MOUSE_BTN3_DOWN), FUNCNAME_mainMn),
  K_SET_FUNC(K_GEN(0, K_MOUSE(MOVE) + MOUSE_BTN1_DOWN), FUNCNAME_scrollXY),
#endif
};

KeyTabList w3mDefaultFuncKeyTabList = {
  NULL,
  w3mDefaultFuncKeyTab,
  sizeof(w3mDefaultFuncKeyTab) / sizeof(w3mDefaultFuncKeyTab[0]),
  sizeof(w3mDefaultFuncKeyTab) / sizeof(w3mDefaultFuncKeyTab[0]),
};

#ifdef __EMX__
char PcKeymap[256]={
//			  Null
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //	0
//							  S-Tab
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, prevA,   //	8
// A-q	  A-w	  A-E	  A-r	  A-t	  A-y	  A-u	  A-i
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  16
// A-o	  A-p	  A-[	  A-]			  A-a	  A-s
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  24
// A-d	  A-f	  A-g	  A-h	  A-j	  A-k	  A-l	  A-;
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  32
// A-'    A-'		  A-\		  A-x	  A-c	  A-v
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  40
// A-b	  A-n	  A-m	  A-,	  A-.	  A-/		  A-+
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  48
//			  F1	  F2	  F3	  F4	  F5
  nulcmd, nulcmd, nulcmd, ldhelp, nulcmd, qquitfm,nulcmd, nulcmd,  //  56
// F6	  F7	  F8	  F9	  F10			  Home
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, goLineF, //  64
// Up	  PgUp	  A-/	  Left	  5	  Right	  C-*	  End
  movU,	  pgBack, nulcmd, movL,	  nulcmd, movR,	  nulcmd, goLineL, //  72
// Down	  PgDn	  Ins	  Del	  S-F1	  S-F2	  S-F3	  S-F4
  movD,	  pgFore, mainMn, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  80
// S-F5	  S-F6	  S-F7	  S-F8	  S-F9	  S-F10	  C-F1	  C-F2
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  88
// C-F3	  C-F4	  C-F5	  C-F6	  C-F7	  C-F8	  C-F9	  C-F10
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  //  96
// A-F1	  A-F2	  A-F3	  A-F4	  A-F5	  A-F6	  A-F7	  A-F8
  nulcmd, nulcmd, nulcmd, qquitfm,nulcmd, nulcmd, nulcmd, nulcmd,  // 104
// A-F9	  A-F10	  PrtSc	  C-Left  C-Right C-End	  C-PgDn  C-Home
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 112
// A-1	  A-2	  A-3	  A-4	  A-5	  A-6	  A-7/8	  A-9
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 120
// A-0	  A -	  A-=		  C-PgUp  F11	  F12	  S-F11
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 128
// S-F12  C-F11	  C-F12	  A-F11	  A-F12	  C-Up	  C-/	  C-5
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 136
// S-*	  C-Down  C-Ins	  C-Del	  C-Tab	  C -	  C-+
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 144
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 152
//				  A -	  A-Tab	  A-Enter
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 160
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 168
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 176
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 184
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 192
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 200
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 208
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 216
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 224
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 232
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd,  // 240
  nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd, nulcmd   // 248
};
#endif
