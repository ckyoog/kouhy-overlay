#include "config.h"
%%BEGIN schemetab
#undef def_scheme
#define def_scheme(name, cmd, real_name, port, internal) name,&schemetable[cmd]
#include "scheme.h"
