%%begin entity_tab
#undef def_entity
#define def_entity(name, uc, strict) # name,&entity_descv[ENTITY_INDEX_ ## name]
#include "entity.h"
